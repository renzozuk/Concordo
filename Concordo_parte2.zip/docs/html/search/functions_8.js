var searchData=
[
  ['onlyspaces_168',['onlySpaces',['../main_8cpp.html#a608e4172c1d22eb1662ead5122e66228',1,'main.cpp']]]
];
