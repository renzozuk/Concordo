var searchData=
[
  ['printchannels_169',['printChannels',['../classServer.html#aba4a136c912f68b9ca2305c85a629db2',1,'Server::printChannels()'],['../classSystem.html#a36ae0a35c6b1364dceca3f188c127242',1,'System::printChannels()']]],
  ['printmessages_170',['printMessages',['../classSystem.html#ad3be898dfe00394b6d4814d664f626b2',1,'System']]]
];
