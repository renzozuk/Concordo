var searchData=
[
  ['newchannel_167',['newChannel',['../classSystem.html#a82164836a544570377390f22af619ad9',1,'System']]]
];
