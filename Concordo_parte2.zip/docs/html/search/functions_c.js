var searchData=
[
  ['textchannel_189',['TextChannel',['../classTextChannel.html#a27dc7247d18c236392b503fc8c57ad55',1,'TextChannel::TextChannel()'],['../classTextChannel.html#ab464df64d6b38bc23b7708b0708bfe79',1,'TextChannel::TextChannel(string, string)']]]
];
