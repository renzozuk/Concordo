var searchData=
[
  ['sendingmessage_61',['sendingMessage',['../classServer.html#a026ac8d8da68504cd5462b147461ac76',1,'Server::sendingMessage()'],['../classSystem.html#a97b5eb5dcbbb3f428d9946d90ba33329',1,'System::sendingMessage()']]],
  ['server_62',['Server',['../classServer.html',1,'Server'],['../classServer.html#ad5ec9462b520e59f7ea831e157ee5e59',1,'Server::Server()'],['../classServer.html#a028990d1cdfd2a8eb64d79296f23572b',1,'Server::Server(int o, const string &amp;n)']]],
  ['server_2ecpp_63',['server.cpp',['../server_8cpp.html',1,'']]],
  ['server_2eh_64',['server.h',['../server_8h.html',1,'']]],
  ['setcurrentchannel_65',['setCurrentChannel',['../classSystem.html#a15e7e3b270b46efb890029fe6aee34f1',1,'System']]],
  ['setcurrentserver_66',['setCurrentServer',['../classSystem.html#ad1de91e5ec17795f2994de4ee0635bc1',1,'System']]],
  ['setdescription_67',['setDescription',['../classServer.html#aa4431a1c517c4d4473ab261fb2d66a3d',1,'Server']]],
  ['setinvitecode_68',['setInviteCode',['../classServer.html#a20828ef03a381e0063b6a1a77fa22370',1,'Server']]],
  ['setlastmessage_69',['setLastMessage',['../classChannel.html#a6a8026cc73ccd5fbada8fb9e14c5cfe6',1,'Channel::setLastMessage()'],['../classVoiceChannel.html#a9a8e44c7d0ed27bff274b49de5262033',1,'VoiceChannel::setLastMessage()']]],
  ['setloggedinuser_70',['setLoggedInUser',['../classSystem.html#a12354c66ecb3c87dfc47cd80431b9699',1,'System']]],
  ['setserverdescription_71',['setServerDescription',['../classSystem.html#a77590a4780762bd95b1bf1796a656f39',1,'System']]],
  ['setserverinvitecode_72',['setServerInviteCode',['../classSystem.html#a5dd00e64d9759d561ef9224d9bca2e05',1,'System']]],
  ['settingserverdescription_73',['settingServerDescription',['../main_8cpp.html#a507c56a6993e9ef0f724800f44c9d1ae',1,'main.cpp']]],
  ['settingserverinvitecode_74',['settingServerInviteCode',['../main_8cpp.html#a924a9af4b202e6095a3359143ee13f17',1,'main.cpp']]],
  ['signup_75',['signup',['../main_8cpp.html#a5ece2743fd4d75edf98346f47cd34b80',1,'main.cpp']]],
  ['splitting_76',['splitting',['../main_8cpp.html#aad322dd5d64050ad75d6cb3e5d884f2d',1,'main.cpp']]],
  ['system_77',['System',['../classSystem.html',1,'System'],['../classSystem.html#ae317936c9bcf1374d61745572e0f2f8a',1,'System::System()']]],
  ['system_2ecpp_78',['system.cpp',['../system_8cpp.html',1,'']]],
  ['system_2eh_79',['system.h',['../system_8h.html',1,'']]]
];
