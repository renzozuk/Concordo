var searchData=
[
  ['voicechannel_191',['VoiceChannel',['../classVoiceChannel.html#abd67aa3b820f2feeca0148e9ffec5564',1,'VoiceChannel::VoiceChannel()'],['../classVoiceChannel.html#a2632ff34235028fd485851c752366b3f',1,'VoiceChannel::VoiceChannel(string, string)']]]
];
