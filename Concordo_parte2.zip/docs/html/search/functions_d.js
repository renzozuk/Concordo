var searchData=
[
  ['user_190',['User',['../classUser.html#a4a0137053e591fbb79d9057dd7d2283d',1,'User::User()'],['../classUser.html#a5f3626cb9eb105e87d457a58a87a5bbb',1,'User::User(int y, const string &amp;e, const string &amp;p, const string &amp;n)']]]
];
