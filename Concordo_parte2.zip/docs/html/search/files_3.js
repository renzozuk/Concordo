var searchData=
[
  ['textchannel_2ecpp_113',['textchannel.cpp',['../textchannel_8cpp.html',1,'']]],
  ['textchannel_2eh_114',['textchannel.h',['../textchannel_8h.html',1,'']]]
];
