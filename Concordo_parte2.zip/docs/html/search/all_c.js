var searchData=
[
  ['textchannel_80',['TextChannel',['../classTextChannel.html',1,'TextChannel'],['../classTextChannel.html#a27dc7247d18c236392b503fc8c57ad55',1,'TextChannel::TextChannel()'],['../classTextChannel.html#ab464df64d6b38bc23b7708b0708bfe79',1,'TextChannel::TextChannel(string, string)']]],
  ['textchannel_2ecpp_81',['textchannel.cpp',['../textchannel_8cpp.html',1,'']]],
  ['textchannel_2eh_82',['textchannel.h',['../textchannel_8h.html',1,'']]],
  ['type_83',['type',['../classChannel.html#a4ff8226abc544520dd121d9141cef953',1,'Channel']]]
];
