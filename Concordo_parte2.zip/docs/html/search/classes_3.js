var searchData=
[
  ['textchannel_101',['TextChannel',['../classTextChannel.html',1,'']]]
];
