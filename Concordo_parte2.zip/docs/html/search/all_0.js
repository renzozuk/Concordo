var searchData=
[
  ['addchanneltoserver_0',['addChannelToServer',['../classServer.html#a295189591ec882e9ed960eb53a27895b',1,'Server']]],
  ['addmessagetochannel_1',['addMessageToChannel',['../classChannel.html#a558006c6a06fd844e2d59c7361709c48',1,'Channel::addMessageToChannel()'],['../classTextChannel.html#a06651e1a415bd25e4cea7de9ea5d679c',1,'TextChannel::addMessageToChannel()']]],
  ['addservertosystem_2',['addServerToSystem',['../classSystem.html#aad6e5658dc8c78f4118ba16d500ec3ef',1,'System']]],
  ['addusertosystem_3',['addUserToSystem',['../classSystem.html#a7e8ac0b947f89af1b2c7a8f2cfa7e226',1,'System']]],
  ['alexistchannel_4',['alExistChannel',['../classServer.html#a364fc998bc3d5da97738675d8712bb76',1,'Server']]],
  ['alexistserver_5',['alExistServer',['../classSystem.html#a60259544cd26e1c21db54dd02efdcf7d',1,'System']]],
  ['alexistuser_6',['alExistUser',['../classSystem.html#a114ea1f48109814c933923039fdd6338',1,'System']]]
];
