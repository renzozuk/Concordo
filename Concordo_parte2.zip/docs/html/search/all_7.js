var searchData=
[
  ['name_53',['name',['../classChannel.html#ada27be4a604630621c5de998c7f4a418',1,'Channel']]],
  ['newchannel_54',['newChannel',['../classSystem.html#a82164836a544570377390f22af619ad9',1,'System']]]
];
