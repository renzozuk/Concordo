var searchData=
[
  ['disconnect_13',['disconnect',['../classSystem.html#a66379777d789c071beb96b3b0253f212',1,'System']]]
];
