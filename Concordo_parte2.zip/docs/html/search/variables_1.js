var searchData=
[
  ['type_200',['type',['../classChannel.html#a4ff8226abc544520dd121d9141cef953',1,'Channel']]]
];
