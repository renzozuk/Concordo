var searchData=
[
  ['main_165',['main',['../main_8cpp.html#a0ddf1224851353fc92bfbff6f499fa97',1,'main.cpp']]],
  ['message_166',['Message',['../classMessage.html#a4fc4f717b634e66070366cb7722d7761',1,'Message::Message()'],['../classMessage.html#af4ed78af8096daf0140c4780f39a8a1b',1,'Message::Message(string, int, string)']]]
];
