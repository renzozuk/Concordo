var searchData=
[
  ['name_199',['name',['../classChannel.html#ada27be4a604630621c5de998c7f4a418',1,'Channel']]]
];
